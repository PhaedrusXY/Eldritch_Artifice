# Prototype architecture notes

This jar is a vertical-slice test artifact, not the final architecture.

The runtime Java code avoids compile-time references to Minecraft/Forge classes except the
standard `@Mod` annotation. This is deliberate: the current build environment cannot download
ForgeGradle/Minecraft/dependency artifacts. The jar therefore uses narrow reflection adapters
for the first testable systems.

Do not extend this pattern across the finished mod. Once the M&A 3.1.11 API jar and DD 5.4.4
jar are available in the development workspace, replace runtime reflection with typed Forge,
M&A, and DD integration services.

The public `EldritchApi` class is the intended seam for later M&A content hooks.

Current saved keys use the `eldritchartifice_` prefix in Forge persistent player data.


0.1.2 replaces ambiguous runtime method-shape fallbacks for command feedback with exact Minecraft 1.20.1 SRG names and adds structured runtime logging.
