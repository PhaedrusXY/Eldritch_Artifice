package com.eldritchartifice;

import net.minecraftforge.fml.common.Mod;

/**
 * Bootstrap for the Eldritch Artifice prototype.
 */
@Mod(EldritchArtifice.MOD_ID)
public final class EldritchArtifice {
    public static final String MOD_ID = "eldritchartifice";
    public static final String VERSION = "0.1.2-prototype";

    public EldritchArtifice() {
        RuntimeLog.info("Bootstrapping " + VERSION);

        ForgeEventBridge eventBridge = new ForgeEventBridge();
        eventBridge.register(
                "net.minecraftforge.event.TickEvent$PlayerTickEvent",
                event -> safeHandle("player tick", () -> WarpService.onPlayerTick(event)));
        eventBridge.register(
                "net.minecraftforge.event.entity.player.PlayerEvent$PlayerLoggedInEvent",
                event -> safeHandle("login", () -> WarpService.onLogin(event)));
        eventBridge.register(
                "net.minecraftforge.event.entity.player.PlayerEvent$PlayerLoggedOutEvent",
                event -> safeHandle("logout", () -> WarpService.onLogout(event)));
        eventBridge.register(
                "net.minecraftforge.event.entity.player.PlayerEvent$PlayerRespawnEvent",
                event -> safeHandle("respawn", () -> WarpService.onRespawn(event)));
        eventBridge.register(
                "net.minecraftforge.event.entity.player.PlayerEvent$PlayerChangedDimensionEvent",
                event -> safeHandle("dimension change", () -> WarpService.onDimensionChanged(event)));
        eventBridge.register(
                "net.minecraftforge.event.entity.player.PlayerEvent$Clone",
                event -> safeHandle("player clone", () -> WarpService.onClone(event)));
        eventBridge.register(
                "net.minecraftforge.event.RegisterCommandsEvent",
                event -> safeHandle("command registration", () -> EldritchCommands.register(event)));

        RuntimeLog.info("Prototype event hooks registered.");
    }

    private static void safeHandle(String name, Runnable action) {
        try {
            action.run();
        } catch (Throwable throwable) {
            RuntimeLog.error("Failed during " + name + ": " + throwable, throwable);
                    }
    }
}
