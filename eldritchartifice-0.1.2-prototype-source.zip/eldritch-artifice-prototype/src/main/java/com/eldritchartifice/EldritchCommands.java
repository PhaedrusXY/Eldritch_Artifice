package com.eldritchartifice;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.function.Predicate;

/**
 * Operator-only prototype commands.
 */
final class EldritchCommands {
    private EldritchCommands() {
    }

    static void register(Object event) {
        try {
            Object dispatcher = event.getClass().getMethod("getDispatcher").invoke(event);
            Object root = literal("eldritch");
            requireOperator(root);

            addSubcommand(root, "status", player -> {
                WarpState state = WarpService.state(player);
                RuntimeMinecraft.sendMessage(player, "[Eldritch] " + WarpService.statusLine(state));
            });
            addSubcommand(root, "attention5", player -> {
                EldritchApi.drawAttention(player, 5, "debug_command");
                RuntimeMinecraft.sendMessage(player, "[Eldritch] Drew 5 Attention.");
            });
            addSubcommand(root, "attention25", player -> {
                EldritchApi.drawAttention(player, 25, "debug_command");
                RuntimeMinecraft.sendMessage(player, "[Eldritch] Drew 25 Attention.");
            });
            addSubcommand(root, "lingering5", player -> {
                EldritchApi.addLingeringWarp(player, 5, "debug_command");
                RuntimeMinecraft.sendMessage(player, "[Eldritch] Added 5 Lingering Warp.");
            });
            addSubcommand(root, "permanent1", player -> {
                EldritchApi.addPermanentWarp(player, 1, "debug_command");
                RuntimeMinecraft.sendMessage(player, "[Eldritch] Added 1 Permanent Warp.");
            });
            addSubcommand(root, "forceevent", WarpService::forceEvent);
            addSubcommand(root, "clear", player -> {
                WarpService.clear(player);
                RuntimeMinecraft.sendMessage(
                        player,
                        "[Eldritch] Warp, Pressure, and Exposure cleared.");
            });

            Method register = dispatcher.getClass().getMethod(
                    "register",
                    Class.forName("com.mojang.brigadier.builder.LiteralArgumentBuilder"));
            register.invoke(dispatcher, root);
            RuntimeLog.info("Registered /eldritch prototype commands.");
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Unable to register /eldritch commands.", exception);
        }
    }

    private static void addSubcommand(Object root, String name, PlayerAction action)
            throws ReflectiveOperationException {
        Object child = literal(name);
        Object command = commandProxy(name, action);

        Method executes = child.getClass().getMethod(
                "executes",
                Class.forName("com.mojang.brigadier.Command"));
        executes.invoke(child, command);

        Method then = root.getClass().getMethod(
                "then",
                Class.forName("com.mojang.brigadier.builder.ArgumentBuilder"));
        then.invoke(root, child);
    }

    private static Object literal(String value) throws ReflectiveOperationException {
        Class<?> commandsClass = Class.forName("net.minecraft.commands.Commands");
        Class<?> literalBuilderClass =
                Class.forName("com.mojang.brigadier.builder.LiteralArgumentBuilder");

        Method fallback = null;
        for (Method method : commandsClass.getMethods()) {
            if (!Modifier.isStatic(method.getModifiers())
                    || method.getParameterCount() != 1
                    || method.getParameterTypes()[0] != String.class
                    || method.getReturnType() != literalBuilderClass) {
                continue;
            }
            if (method.getName().equals("literal")) {
                return method.invoke(null, value);
            }
            fallback = method;
        }

        if (fallback == null) {
            throw new IllegalStateException("Minecraft Commands.literal factory was not found.");
        }
        return fallback.invoke(null, value);
    }

    private static void requireOperator(Object root) throws ReflectiveOperationException {
        Method requires = root.getClass().getMethod("requires", Predicate.class);
        Predicate<Object> predicate = EldritchCommands::hasOperatorPermission;
        requires.invoke(root, predicate);
    }

    private static boolean hasOperatorPermission(Object commandSource) {
        try {
            Method method = namedMethod(
                    commandSource.getClass(),
                    new String[]{"hasPermission", "m_6761_"},
                    boolean.class,
                    int.class);
            return method != null && (Boolean) method.invoke(commandSource, 2);
        } catch (ReflectiveOperationException exception) {
            RuntimeLog.warn("Could not evaluate command permission: " + exception);
            return false;
        }
    }

    private static Object commandProxy(String name, PlayerAction action) throws ClassNotFoundException {
        Class<?> commandClass = Class.forName("com.mojang.brigadier.Command");
        return Proxy.newProxyInstance(
                commandClass.getClassLoader(),
                new Class<?>[]{commandClass},
                (proxy, method, args) -> {
                    if (method.getDeclaringClass() == Object.class) {
                        return switch (method.getName()) {
                            case "toString" -> "eldritchartifice.command." + name;
                            case "hashCode" -> System.identityHashCode(proxy);
                            case "equals" -> proxy == (args == null || args.length == 0 ? null : args[0]);
                            default -> defaultValue(method.getReturnType());
                        };
                    }
                    if (!method.getName().equals("run") || args == null || args.length != 1) {
                        return defaultValue(method.getReturnType());
                    }
                    Object context = args[0];
                    Object source = context.getClass().getMethod("getSource").invoke(context);
                    RuntimeLog.info("Executing /eldritch " + name + ".");
                    Object player = commandPlayer(source);
                    if (player == null) {
                        return 0;
                    }
                    action.run(player);
                    return 1;
                });
    }

    private static Object commandPlayer(Object source) {
        try {
            Class<?> serverPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
            Method method = namedMethod(
                    source.getClass(),
                    new String[]{"getPlayerOrException", "m_81375_", "getPlayer", "m_230896_"},
                    serverPlayerClass);
            if (method == null) {
                RuntimeLog.warn("Command source did not expose a ServerPlayer accessor.");
                return null;
            }
            return method.invoke(source);
        } catch (ReflectiveOperationException exception) {
            RuntimeLog.error("Unable to resolve command player: " + exception, exception);
            return null;
        }
    }

    private static Method namedMethod(
            Class<?> owner,
            String[] names,
            Class<?> returnType,
            Class<?>... parameterTypes) {
        for (String name : names) {
            try {
                Method method = owner.getMethod(name, parameterTypes);
                if (method.getReturnType() == returnType) {
                    return method;
                }
            } catch (NoSuchMethodException ignored) {
            }
        }
        return null;
    }

    private static Object defaultValue(Class<?> type) {
        if (!type.isPrimitive()) {
            return null;
        }
        if (type == boolean.class) {
            return false;
        }
        if (type == int.class) {
            return 0;
        }
        return null;
    }

    @FunctionalInterface
    private interface PlayerAction {
        void run(Object player);
    }
}
