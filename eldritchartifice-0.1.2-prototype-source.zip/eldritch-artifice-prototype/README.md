# Eldritch Artifice — Prototype 0.1.2

Target stack:

- Minecraft 1.20.1
- Forge 47.x (source baseline: recommended 47.4.10)
- Mana and Artifice 3.1.11
- Dimensional Doors 5.4.4 Forge

## Implemented in this prototype

- Hard load dependency on `mna` and `dimdoors`
- Universal player Warp: transient, lingering, permanent
- Persistent player data
- Death/respawn clone support
- Nonlinear Warp Pressure
- Pressure decay after quiet periods
- Transient Warp decay
- Coarse harmless Warp event scheduler
- Separate Azathoth Exposure
- Limbo detection through `dimdoors:limbo`
- Placeholder Azathoth perception thresholds
- Operator debug commands

## Debug commands

- `/eldritch status`
- `/eldritch attention5`
- `/eldritch attention25`
- `/eldritch lingering5`
- `/eldritch permanent1`
- `/eldritch forceevent`
- `/eldritch clear`

## Test sequence

1. Start a 1.20.1 Forge client/server with M&A 3.1.11 and DD 5.4.4.
2. Join as an operator and run `/eldritch status`.
3. Run `/eldritch attention5`, then `/eldritch status`.
4. Run `/eldritch attention25`; wait for event messages or use `/eldritch forceevent`.
5. Log out/in and confirm values persist.
6. Die/respawn and confirm values persist.
7. Enter Limbo and confirm Exposure rises over time.
8. Accumulate Warp in Limbo and confirm perception threshold messages appear.
9. Restart the world/server and confirm persisted values remain.

## Not implemented yet

- M&A Eldritch faction registration
- M&A overcasting / ire replacement
- synchronized client Warp packet/HUD
- selective manifestation entity rendering
- Displacement
- Enhanced Recall
- Monolith behavior hooks
- Azathoth sky renderer
- Time Warp
- Tier 5 armor
- final sound system

## Build status

The handoff jar was compiled to Java 17 bytecode and statically inspected for resource/metadata
integrity. The build environment cannot launch Forge or download the game/dependency artifacts,
so the jar still needs the in-pack smoke test in `TESTING.md`.

The runtime bootstrap intentionally uses reflection only for this first vertical slice. The final
mod should switch to typed Forge/M&A/Dimensional Doors integration once the exact dependency jars
are available for local inspection.


## 0.1.2 compatibility fix

Fixed Starter Kit 8.1 command-event compatibility and corrected ResourceKey dimension resolution for Limbo detection.


## 0.1.2 command feedback fix

The minimal Forge 47.4.10 test showed that `/eldritch` could be entered without visible feedback.
The bootstrap build previously resolved several obfuscated Minecraft methods by shape alone. That is
unsafe when multiple methods share the same signature.

0.1.2 pins the relevant Minecraft 1.20.1 SRG names:

- `Component.literal(String)` -> `m_237113_`
- `ServerPlayer.sendSystemMessage(Component)` -> `m_213846_`
- `CommandSourceStack.hasPermission(int)` -> `m_6761_`
- `CommandSourceStack.getPlayerOrException()` -> `m_81375_`

The Mojang-mapped names remain accepted in development environments. Command execution and
prototype lifecycle messages now use SLF4J when available so the live log gives an unambiguous trace.
