# Eldritch Artifice 0.1.2 Prototype — Live Test

Use the minimal dependency profile first.

## Command path

Run:

```text
/eldritch status
/eldritch attention5
/eldritch status
/eldritch forceevent
```

Expected:
- every command produces visible chat feedback, except `forceevent` whose feedback is the generated event text;
- after `attention5`, status shows transient Warp > 0 and Pressure > 0;
- `latest.log` contains an `Executing /eldritch ...` line for every subcommand;
- `latest.log` contains the Warp mutation after `attention5`.

## Persistence

Save and quit, reopen the same world, then run:

```text
/eldritch status
```

Transient Warp may have decayed depending on elapsed in-world ticks, but the state must not reset
simply because the client restarted.

## Limbo

Enter `dimdoors:limbo` and run:

```text
/eldritch status
```

Expected:
- dimension is `dimdoors:limbo`;
- Exposure rises while remaining in Limbo;
- perception text appears as thresholds are reached.

## Failure information

If chat is still silent, upload `latest.log`. Version 0.1.2 should make command dispatch, player
resolution, and message-delivery failures explicit in the log.
