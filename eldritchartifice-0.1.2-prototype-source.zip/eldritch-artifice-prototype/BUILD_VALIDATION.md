# Eldritch Artifice 0.1.2 Prototype — Build Validation

## Live issue addressed

In the minimal Forge 47.4.10 environment, `/eldritch` commands no longer threw errors but produced
no visible response. The log also did not provide a reliable prototype execution trace.

The remaining bootstrap reflection had ambiguous method selection:
- `Component.literal(String)` shared its signature with other component factories.
- `ServerPlayer` exposes multiple component-related methods.
- `CommandSourceStack` player/permission accessors are obfuscated in production.

## 0.1.2 fix

The runtime adapter now prefers both Mojang development names and exact Minecraft 1.20.1 SRG names:
- `Component.literal(String)` / `m_237113_`
- `ServerPlayer.sendSystemMessage(Component)` / `m_213846_`
- `CommandSourceStack.hasPermission(int)` / `m_6761_`
- `CommandSourceStack.getPlayerOrException()` / `m_81375_`
- nullable player fallback `getPlayer()` / `m_230896_`

Lifecycle and command execution tracing now uses SLF4J reflectively, with stdout/stderr only as a fallback.

## Local validation

- Compiled all production sources with `javac --release 17`.
- Final jar does not contain the Forge compile stub.
- `mods.toml` reports `0.1.2-prototype`.
- Dynamic command proxy retains stable `toString`, identity `equals`, and identity `hashCode`.
- SRG smoke harness deliberately provided a misleading same-signature Component method and verified:
  - literal text factory selection;
  - player system-message delivery;
  - operator permission lookup;
  - command-source player lookup.
- Smoke harness passed under Java 17.

## Next live checks

Run in the minimal Forge 47.4.10 profile:

1. `/eldritch status`
2. `/eldritch attention5`
3. `/eldritch status`
4. `/eldritch forceevent`
5. save/quit/reload
6. `/eldritch status`

Expected log markers include:
- `Bootstrapping 0.1.2-prototype`
- `Registered /eldritch prototype commands`
- `Loaded Warp state`
- `Executing /eldritch status`
- `Executing /eldritch attention5`
- `gained 5 transient Warp`

Expected chat feedback includes the status line and the Attention confirmation.
